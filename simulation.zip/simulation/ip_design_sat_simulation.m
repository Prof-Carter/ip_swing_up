clear
format compact

h = 0.01;        % �T���v�����O����

Tf1 = 0.08;      % ���[�p�X�t�B���^�̎��萔
Tf2 = 0.08;      % ���[�p�X�t�B���^�̎��萔

% =============================================
% If Action Subsystem (Swing-up Control) ��
% Saturation ���g�p����ꍇ�i����F1.75 [V]�j

theta2stb =  25; % deg
% omega2stb = 300; % deg/s  <=== ���@�����̏ꍇ
omega2stb = 500; % deg/s  <==== ����`�V�~�����[�V�����̏ꍇ
theta2sw  = 120; % deg

ksw   = 8;       % �U��グ�Q�C��
v_sat = 1.75;    % �U��グ���䎞�̐�����͂̏���l

% =============================================
g  = 9.81e+00;
L1 = 7.00e-02;

a1 = 1.53e+01;
b1 = 7.06e+01;

a2 = 1.10e-01;
b2 = 3.59e-02;

E = [ 1  0  0  0
      0  1  0  0
      0  0  1  0
      0  L1 0  a2 ];
F = [ 0  1  0  0
      0 -a1 0  0
      0  0  0  1
      0  0  g -b2 ];
G = [ 0
      b1
      0
      0 ];

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �V�X�e���s�� A, B')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

A = inv(E)*F
B = inv(E)*G

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �d�ݍs�� Q, R')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

q1 = 0.2;
q3 = 100;

Q = diag([q1 0 q3 0])
R = 1

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �œK���M�����[�^�ɂ��R���g���[���Q�C�� K')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

K = -lqr(A,B,Q,R)

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' A + B*K �̌ŗL�l')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

eig(A + B*K)

v = ver('MATLAB');
if v.Release < "(R2018a)"
    disp(' �o�[�W�������Ή����Ă��܂���')
elseif v.Release >= "(R2018a)"
    sim('sim_sfbk_ip_swing_sat_R2018a')
end

% ----------------------------------------------
for i = 1:4
    figure(i)
    subplot('Position',[0.15 0.15 0.775 0.775])
end

% ----------------------------------------------
t_end = 5;

% ----------------------------------------------
figure(1)
plot(t,v,'LineWidth',1.5)
hold on
plot([0.1 0.1],   [-9 9],'g')
plot([0 t(end)],[-v_sat -v_sat],'m')
plot([0 t(end)],[ v_sat  v_sat],'m')
hold off

set(gca,'FontSize',14,'FontName','Arial')
xlabel('$t$ [s]','Interpreter','latex','FontSize',16)
ylabel('$v$ [V]','Interpreter','latex','FontSize',16)

xlim([0 t_end])
ylim([-9 9])

set(gca,'XTick',0:1:10)
set(gca,'YTick',-9:3:9)

grid on

% ----------------------------------------------
figure(2)
plot(t,x(:,1)*180/pi,'LineWidth',1.5)

set(gca,'FontSize',14,'FontName','Arial')
xlabel('$t$ [s]','Interpreter','latex','FontSize',16)
ylabel('$\theta_1$ [deg]','Interpreter','latex','FontSize',16)

xlim([0 t_end])
ylim([-90 180])

set(gca,'XTick',0:1:10)
set(gca,'YTick',-90:45:180)

grid on

% ----------------------------------------------
figure(3)
plot(t,phi2*180/pi,'LineWidth',1.5)
hold on
plot([0 t(end)],-(180 - theta2sw)*[1 1],'r')
plot([0 t(end)], (180 - theta2sw)*[1 1],'r')
hold off

set(gca,'FontSize',14,'FontName','Arial')
xlabel('$t$ [s]','Interpreter','latex','FontSize',16)
ylabel('$\phi_2$ [deg]','Interpreter','latex','FontSize',16)

xlim([0 t_end])
ylim([-225 180])

set(gca,'XTick',0:1:10)
set(gca,'YTick',-270:45:270)

grid on

% ----------------------------------------------
figure(4)
plot(t,x(:,3)*180/pi,'LineWidth',1.5)
hold on
plot([0 t(end)],-theta2stb*[1 1],'b')
plot([0 t(end)], theta2stb*[1 1],'b')
plot([0 t(end)],-theta2sw*[1 1],'r')
plot([0 t(end)], theta2sw*[1 1],'r')
hold off

set(gca,'FontSize',14,'FontName','Arial')
xlabel('$t$ [s]','Interpreter','latex','FontSize',16)
ylabel('$\theta_2$ [deg]','Interpreter','latex','FontSize',16)

xlim([0 t_end])
ylim([-200 200])

set(gca,'XTick',0:1:10)
set(gca,'YTick',-180:45:180)

grid on

% ----------------------------------------------
figure(1); movegui('north')
figure(2); movegui('northeast')
figure(3); movegui('south')
figure(4); movegui('southeast')



